# Ike's Love Test

## Introduction
This web application helps people discover their dominant love language through an interactive quiz of 20 questions. The web applications analyzes the responses and provides insights into the persons love language preferences.


## Features
 - User registration and login
 - Love language test with multiple questions
 - Dynamic floating hearts animation
 - Share test results on X, Facebook, and Gmail
 - Responsive design for devices

## Installation and Setup

### Prerequisites
- Python
- Flask
- Flask-SQLAlchemy
- Flask-Login
- A web browser

### Clone the Repository
https://github.com/ikerollins/love.git

### install dependencies
pip install -r requirements.txt
The requirements.txt has been frozen so that the exact version of all packages I have been using can be used within the environment of the new user

### Usage
1. **Run the application in the terminal**
    - python app.py

2. **Follow the on screen instructions**
    - Register your account by creating desired username and password
    - Login using your existing username and password
    - Take the test and answer each question by selecting one of the two options
    - Once completed, view your results and share if desired. You can also restart the test if wamted.

## Project Structure
lovelanguagetest/
love-test/
│
├── templates/
│ ├── base.html
│ ├── index.html
│ ├── register.html
│ ├── login.html
│ ├── questions.html
│ └── result.html
│
├── static/
│ ├── css/
│ │ └── styles.css
│ └── images/
│ └── lovepic.png
│
├── app.py
├── DESIGN.md
├── README.md
└── requirements.txt

## FAQs

**Q:**
**A:**

**Q:** How do I reset the Test?
**A:** Simply refresh the page or restart the application.

**Q:** Can I add more questions?
**A:** Yes, you can modify the questions list in the app.py file to add or remove questions.

**Q:** How do I stop the server?
**A:** Press 'Ctrl+C' in the terminal where the server is running to stop the Flask server

**Q:** Can I customize the look and feel of the application?
**A:** Yes, you can modify the CSS file located in 'static/css/styles.css' to change the look and feel.

**Q:** Can I deploy this application to a web server?
**A:** Yes, you can deploy this application to any web server that supports Python and Flask. Common options are Heroku, AWS, DigitalOcean, and others. Follow their specific instructions to do so.


