from flask import Flask, render_template, request, redirect, url_for, session, flash
from flask_sqlalchemy import SQLAlchemy
from flask_login import LoginManager, UserMixin, login_user, logout_user, login_required, current_user
import hashlib
from urllib.parse import quote

app = Flask(__name__)
app.secret_key = 'your_secret_key'
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///users.db'
db = SQLAlchemy(app)
login_manager = LoginManager(app)
login_manager.login_view = 'login'

questions = [
    ("I like to receive notes of affirmation.", "I like it when you hug me."),
    ("I feel loved when you help me with my chores.", "I like to spend one-on-one time with you."),
    ("I feel loved when you give me gifts.", "I enjoy receiving compliments."),
    ("I like to hold hands with you.", "I appreciate it when you run errands for me."),
    ("I love taking walks and talking with you.", "I feel special when you give me thoughtful presents."),
    ("I feel appreciated when you acknowledge my efforts.", "I enjoy cuddling with you."),
    ("I feel supported when you do things to help me.", "I cherish the time we spend together."),
    ("I like it when you surprise me with small gifts.",
     "I am uplifted when you express your feelings to me."),
    ("I feel close to you when we physically touch.",
     "I am grateful when you take care of tasks that are difficult for me."),
    ("I treasure our moments of uninterrupted time together.",
     "I love it when you give me a gift for no special reason."),
    ("I feel loved when you spend quality time with me.", "I feel special when you give me a gift."),
    ("I feel appreciated when you express your feelings to me.", "I feel close to you when we hold hands."),
    ("I enjoy it when you do something practical to help me.",
     "I love receiving a heartfelt letter from you."),
    ("I feel happy when you touch my arm.", "I feel important when you help me with my responsibilities."),
    ("I feel cared for when you listen to me attentively.",
     "I feel valued when you surprise me with a small present."),
    ("I feel close to you when we sit and talk for hours.",
     "I appreciate it when you give me a thoughtful card."),
    ("I feel supported when you help me out with a task.",
     "I feel loved when you hug me for no reason."),
    ("I feel cherished when we go on a date.", "I feel uplifted when you give me a sincere compliment."),
    ("I feel appreciated when you thank me for the things I do.",
     "I feel important when you spend time doing things I enjoy."),
    ("I feel loved when you bring me a surprise treat.",
     "I feel happy when you spend a lazy day with me.")
]

lovelanguages = {
    "Words of Affirmation": 0,
    "Physical Touch": 0,
    "Acts of Service": 0,
    "Quality Time": 0,
    "Receiving Gifts": 0,

}

mapping = {
    "I like to receive notes of affirmation.": "Words of Affirmation",
    "I like it when you hug me.": "Physical Touch",
    "I feel loved when you help me with my chores.": "Acts of Service",
    "I like to spend one-on-one time with you.": "Quality Time",
    "I feel loved when you give me gifts.": "Receiving Gifts",
    "I enjoy receiving compliments.": "Words of Affirmation",
    "I like to hold hands with you.": "Physical Touch",
    "I appreciate it when you run errands for me.": "Acts of Service",
    "I love taking walks and talking with you.": "Quality Time",
    "I feel special when you give me thoughtful presents.": "Receiving Gifts",
    "I feel appreciated when you acknowledge my efforts.": "Words of Affirmation",
    "I enjoy cuddling with you.": "Physical Touch",
    "I feel supported when you do things to help me.": "Acts of Service",
    "I cherish the time we spend together.": "Quality Time",
    "I like it when you surprise me with small gifts.": "Receiving Gifts",
    "I am uplifted when you express your feelings to me.": "Words of Affirmation",
    "I feel close to you when we physically touch.": "Physical Touch",
    "I am grateful when you take care of tasks that are difficult for me.": "Acts of Service",
    "I treasure our moments of uninterrupted time together.": "Quality Time",
    "I love it when you give me a gift for no special reason.": "Receiving Gifts",
    "I feel loved when you spend quality time with me.": "Quality Time",
    "I feel special when you give me a gift.": "Receiving Gifts",
    "I feel appreciated when you express your feelings to me.": "Words of Affirmation",
    "I feel close to you when we hold hands.": "Physical Touch",
    "I enjoy it when you do something practical to help me.": "Acts of Service",
    "I love receiving a heartfelt letter from you.": "Receiving Gifts",
    "I feel happy when you touch my arm.": "Physical Touch",
    "I feel important when you help me with my responsibilities.": "Acts of Service",
    "I feel cared for when you listen to me attentively.": "Quality Time",
    "I feel valued when you surprise me with a small present.": "Receiving Gifts",
    "I feel close to you when we sit and talk for hours.": "Quality Time",
    "I appreciate it when you give me a thoughtful card.": "Receiving Gifts",
    "I feel supported when you help me out with a task.": "Acts of Service",
    "I feel loved when you hug me for no reason.": "Physical Touch",
    "I feel cherished when we go on a date.": "Quality Time",
    "I feel uplifted when you give me a sincere compliment.": "Words of Affirmation",
    "I feel appreciated when you thank me for the things I do.": "Words of Affirmation",
    "I feel important when you spend time doing things I enjoy.": "Quality Time",
    "I feel loved when you bring me a surprise treat.": "Receiving Gifts",
    "I feel happy when you spend a lazy day with me.": "Quality Time"
}


class User(UserMixin, db.Model):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(150), unique=True, nullable=False)
    password = db.Column(db.String(150), nullable=False)


@login_manager.user_loader
def load_user(user_id):
    return User.query.get(int(user_id))


def hash_password(password):
    return hashlib.sha256(password.encode()).hexdigest()


def check_password(hashed_password, user_password):
    return hashed_password == hashlib.sha256(user_password.encode()).hexdigest()


@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        username = request.form.get('username')
        password = request.form.get('password')
        hashed_password = hash_password(password)
        new_user = User(username=username, password=hashed_password)
        db.session.add(new_user)
        db.session.commit()
        login_user(new_user)
        return redirect(url_for('index'))
    return render_template('register.html')


@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form.get('username')
        password = request.form.get('password')
        user = User.query.filter_by(username=username).first()
        if user and check_password(user.password, password):
            login_user(user)
            return redirect(url_for('index'))
        flash('Login Unsuccessful. Please check username and password', 'danger')
    return render_template('login.html')


@app.route('/logout')
@login_required
def logout():
    logout_user()
    return redirect(url_for('index'))


@app.route('/')
def index():
    return render_template('index.html')

@app.route('/start')
@login_required
def start():
    session['current_question'] = 0
    session['responses'] = {key: 0 for key in lovelanguages.keys()}
    return redirect(url_for('questions_route'))


@app.route('/questions', methods=['GET', 'POST'])
@login_required
def questions_route():
    current_question = session.get('current_question', 0)

    if request.method == 'POST':
        selected_option = request.form['option']
        lovelanguage = mapping[selected_option]
        session['responses'][lovelanguage] += 1
        current_question += 1
        session['current_question'] = current_question

    if current_question < len(questions):
        question_pair = questions[current_question]
        return render_template('questions.html', question_pair=question_pair)
    else:
        return redirect(url_for('result'))


@app.route('/result')
@login_required
def result():
    responses = session.get('responses', {})
    dominantlanguage = max(responses, key=responses.get)
    share_url = url_for('share', result=dominantlanguage, _external=True)
    tweet_text = quote(f"Check out my dominant love language, _external=True")
    facebook_url = quote(share_url)
    email_subject = quote("My love language Test result")
    email_body = quote(f"Check out my dominant love language: {dominantlanguage}! Take the test: {share_url}")
    return render_template('result.html', language=dominantlanguage)


@app.route('/share')
def share():
    result = request.args.get('result')
    if not result:
        return redirect(url_for('index'))
    return render_templates('share.html', result=result)


if __name__ == '__main__':
    with app.app_context():
        db.create_all()
    app.run(debug=True)
