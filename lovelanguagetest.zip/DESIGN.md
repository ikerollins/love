# Love Language Test Application - Design Document

## Project Overview
The Love language Test Application is designed to help people identify their dominant love language through a series of 20 questions. This app is built using Flask, an easy web framework, and includes HTML and CSS for the front end and styling.

## Project Structure
lovelanguagetest/
│
├── instance/
│ └── users.db
│
├── static/
│ ├── css/
│ │ └── styles.css
│ └── images/
│ └── lovepic.png
│
├── templates/
│ ├── base.html
│ ├── index.html
│ ├── login.html
│ ├── questions.html
│ ├── register.html
│ ├── result.html
│ └── share.html
│
├── app.py
├── DESIGN.md
└── README.md

## Design Decisions
### Flask Framework
Flask was chosen for its simplicity and easy use. It allows for a quick setup and an interactive website that remains dynamic.

### HTML and CSS and Javascript
HTML and CSS and Javascript are used to create visually appealing interface and styling for this app. The goal is to make the app easily navigated by first time users.

### Database
SQLite was used for its ability to put users with accounts in a database so the system could recognize user's accounts and allow them to create and login to accounts.

### Security
Passwords are hashed using the SHA-256 to make sure that user data is secure. Flask-Login is used to manager user sessions securely

### Questions and Responses
The questions are designed to cover the five love languages, and responses are stored in a dicitonary for easy analysis. This allows for straightforward processing and determination of the persons dominant love language.

### Static Files
CSS files are stores in the static directory to keep styles separate from the HTMl content. This makes the project more organized and the styles are easier to change from one access point if needed to be changed for future purposes and theme changes.

## Implementation Details
### User authentication
Is handled with Flask-Login, users can register, log in, and log out. Passwords are securely hashed before being stored in SQLite db.

**Key Routes**
- '/register' , '/login' , and '/logout' handle registration, login, and logout actions within sessions.

### Floating Hearts Animation
The floating hearts animation is acheived by using CSS and ChatGPT suggestions. Multiple hearts are created using the div and @keyframes elements to create multiple hearts and move them from the the bottom to the top of the screen in different time increments and paces.

### Sharing results
The results of the persons test can be shared via X, Facebook, and Gmail. URL encoding is used to make sure that the shared links are correctly formatted. That is where the urllib.parse function is used to encode the result text and URLs. 

## Future Improvements
- **Data Visualization**: Implementing charts to see user preferences and trends.
- **Enhanced UI/UX**: Bettering the design and responsiveness of the application for a better user experience
